select
  snap_id Snapshot,
  dbid,
  instance_number instance,
  begin_interval_time start_time,
  end_interval_time end_time,
  extract(hour from (end_interval_time-begin_interval_time))*60+
  extract(minute from (end_interval_time-begin_interval_time)) Minutes
from
  dba_hist_snapshot
where
  dbid = (select dbid from v$database)
--  and snap_id between xxxx and yyyy   
order by
  dbid, 
  instance_number,
  snap_id