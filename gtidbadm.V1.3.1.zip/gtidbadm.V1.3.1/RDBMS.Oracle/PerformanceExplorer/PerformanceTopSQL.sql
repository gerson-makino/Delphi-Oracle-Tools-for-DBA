select 
  rank.rank,
  max_value,
  avg_value,
  cost_avg,
  sq.sql_id,
  rank.plan_hash_value,
  dbms_lob.substr(sq.sql_text,400,1) sql_text
from
  (select 
     s.sql_id,
     s.plan_hash_value,
     avg(optimizer_cost) cost_avg,
     RANK() OVER (ORDER BY (max(s.ELAPSED_TIME_DELTA)) DESC) rank,
     trunc(avg(s.ELAPSED_TIME_DELTA)/1000000) avg_value,
     trunc(max(s.ELAPSED_TIME_DELTA)/1000000) max_value
   from
     dba_hist_sqlstat s,
     dba_hist_snapshot sn
   where
     sn.dbid = (select dbid from v$database)
     and sn.snap_id=s.snap_id
     and sn.snap_id between xxxx and yyyy
   group by
     s.sql_id,
     s.plan_hash_value) rank,
  dba_hist_sqltext sq
where 
   sq.sql_id = rank.sql_id
   and rank < 21