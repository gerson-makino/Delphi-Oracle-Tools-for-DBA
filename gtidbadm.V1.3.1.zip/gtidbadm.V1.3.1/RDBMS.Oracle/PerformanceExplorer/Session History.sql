select hist.*, p.value*2 maxvalue from
(
select
   to_char(round(sub1.sample_time, 'HH24'), 'DD-MM-YY HH24:MI') xvalue,
   to_char(round(avg(sub1.on_cpu),1) , '000.00000000') yvalue0,
   to_char(round(avg(sub1.waiting),1), '000.00000000') yvalue1 
from
   ( 
     select
        sample_id,
        sample_time,
        sum(decode(session_state, 'ON CPU', 1, 0))  as on_cpu,
        sum(decode(session_state, 'WAITING', 1, 0)) as waiting,
        count(*) as active_sessions
     from
        dba_hist_active_sess_history
--     where
--        dbid = '&dbid'
--        and instance_number = &instance_number
--        and snap_id between &snap_begin and &snap_end
     group by
        sample_id,
        sample_time
   ) sub1
group by
   round(sub1.sample_time, 'HH24')
order by
   round(sub1.sample_time, 'HH24') ) hist,
v$parameter p
where p.name = 'cpu_count'