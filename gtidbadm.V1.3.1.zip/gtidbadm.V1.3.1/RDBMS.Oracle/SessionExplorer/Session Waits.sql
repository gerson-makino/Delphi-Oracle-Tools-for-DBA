select 
  s.sid,s.serial#, 
  decode(w.EVENT, 'SQL*Net message from client','Term Wait', w.event) "event", 
  w.P1TEXT||'= '||w.p1 p1_Event,
  w.P2TEXT||'= '||w.p2 p2_Event,
  w.P3TEXT||'= '||w.p3 p3_Event,
  w.SECONDS_IN_WAIT Wait_Sec, 
  s.serial#,
  s.username, 
  s.program, 
  decode(s.LOCKWAIT,null,' ','(w) Yes') "IS Locked?", 
  decode(w.STATE, 'WAITING','Wait','WAITED UNKNOWN TIME','WaitUt',w.state) "state",  
  sql.sql_text
from
  gv$session s,  
  gv$session_wait w, 
  gv$process p, 
  gv$sqlarea sql
where 
  s.sid = w.sid 
  and w.event not in ('SQL*Net message from client', 
                      'rdbms ipc message',
                      'pmon timer',
                      'smon timer')
  and s.paddr = p.addr 
  and s.sql_address = sql.address (+)