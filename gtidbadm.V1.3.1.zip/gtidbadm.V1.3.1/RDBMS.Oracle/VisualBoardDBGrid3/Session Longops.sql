Select 
  a.sid, 
  a.time_remaining "Remaining",  
  a.elapsed_seconds "Elapsed",   
  substr(a.message,1,200) "Message"  
from 
  gv$session_longops a
where 
  a.time_remaining > 0
order by 3 desc 
