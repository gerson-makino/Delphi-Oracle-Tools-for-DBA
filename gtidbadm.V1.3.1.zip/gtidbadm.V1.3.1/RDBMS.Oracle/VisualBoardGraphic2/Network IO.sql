select 
  decode(statistic#, 335, 'Client Sent', 336, 'Client Received', 338, 'DBLink Sent', 339, 'DBLink Received') type,
  trunc(value/1024) sizekb
from v$sysstat where statistic# in (335,336,338,339)