select 
  'Block Gets' type, sum(block_gets) ct
from v$sess_io
union all
select 
  'Consistent Gets' type, sum(consistent_gets) ct
from v$sess_io
union all
select 
  'Physical Reads' type, sum(physical_reads) ct 
from v$sess_io
union all
select 
  'Block Changes' type, sum(block_changes) ct
from v$sess_io
union all
select 
  'Consistent Changes' type, sum(consistent_changes) ct 
from v$sess_io