select 
  class legend, 
  to_char(aas, '00.000') yvalue
from
(select
   decode(n.wait_class,'User I/O','User I/O','Commit','Commit','Wait') CLASS,
   sum(round(m.time_waited/m.INTSIZE_CSEC,3)) AAS
 from  
   v$waitclassmetric  m,
   v$system_wait_class n
 where 
   m.wait_class_id=n.wait_class_id
   and n.wait_class != 'Idle'
 group by  
   decode(n.wait_class,'User I/O','User I/O', 'Commit','Commit', 'Wait')
union
 select 
   'CPU-ORA' CLASS,
   round(value/100,3) AAS
 from 
   v$sysmetric
 where 
   metric_name='CPU Usage Per Sec'
   and group_id=2
union
  select 
    'CPU-OS'  CLASS ,
    round((prcnt.busy*parameter.cpu_count)/100,3) AAS
  from
   (select value busy from v$sysmetric where metric_name='Host CPU Utilization (%)' and group_id=2 ) prcnt,
   (select value cpu_count from v$parameter where name='cpu_count' )  parameter
union
  select
    'CPU-ORA Wait' CLASS,
    nvl(round( sum(decode(session_state,'ON CPU',1,0))/60,2),0) AAS
  from 
    v$active_session_history ash
  where 
    SAMPLE_TIME > sysdate - (60/(24*60*60))
)


