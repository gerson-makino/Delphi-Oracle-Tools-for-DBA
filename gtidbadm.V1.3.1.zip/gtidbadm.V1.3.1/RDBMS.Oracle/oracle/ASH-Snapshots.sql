select 
  hst.*, 
  dbms_lob.substr(sql.sql_text,400,1) 
from
 (SELECT /*+LEADING(x h) USE_NL(h)*/
   h.sql_id
   , h.sql_plan_hash_value
   , SUM(10) ash_secs
  FROM	
    dba_hist_snapshot x,
    dba_hist_active_sess_history h 
  WHERE	
    h.SNAP_id = X.SNAP_id
    AND h.dbid = x.dbid
    AND h.instance_number = x.instance_number
    and x.begin_interval_time > sysdate-7
  GROUP BY
    h.sql_id, h.sql_plan_hash_value
  ORDER BY
    ash_secs) hst,
  dba_hist_sqltext sql
where 
  hst.sql_id = sql.sql_id
order by 
  hst.ash_secs desc