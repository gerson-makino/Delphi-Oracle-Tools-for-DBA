select  
  s.sid,  
  s.serial#, 
  p.spid,  
  s.username, 
  decode(w.EVENT, 'SQL*Net message from client','Term Wait', w.event) "event",  
  w.SECONDS_IN_WAIT, 
  decode(w.STATE, 'WAITING','Wait','WAITED UNKNOWN TIME','WaitUt',w.state) "state",   
  decode(s.LOCKWAIT,null,' ','Yes') "lockwait", 
  s.status, 
  s.server, 
  s.osuser, 
  s.machine, 
  s.terminal, 
  s.program,   
  s.logon_time,  
  a.sql_text   
from 
 v$session s,  v$sqlarea a, v$session_wait w, v$process p  
where     
  s.sql_address = a.address  
  and s.sql_hash_value = a.hash_value  
  and s.sid = w.sid   
  and s.paddr = p.addr  
