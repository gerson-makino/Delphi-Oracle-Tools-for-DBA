select sid , serial#, username from
v$session where status = 'ACTIVE'