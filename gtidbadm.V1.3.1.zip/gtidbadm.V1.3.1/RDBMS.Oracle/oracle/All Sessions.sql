select
  s.inst_id,        
  s.SID,       
  p.pid,       
  p.spid,      
  s.SERIAL#,    
  decode(s.TYPE,'BACKGROUND','Bkgr','USER','Usr',s.type) "type",   
  s.SERVER,   
  s.USERNAME,   
  decode(s.TERMINAL, 'UNKNOWN ', '-oracle-', s.terminal) terminal,     
  to_char(s.LOGON_TIME,'dd/mm/yy hh24:mi') logon_time,
  floor(s.last_call_et/3600)||':'|| floor(mod(s.last_call_et,3600)/60)||':'|| 
    mod(mod(s.last_call_et,3600),60) "IDLE",
  decode(s.LOCKWAIT,null,'-','(w) Session Locked') "Warning",   
  io.sess_hr Hit_Ratio,    
  decode(s.STATUS,'ACTIVE','Act','INACTIVE','Inact',s.status) "status",  
  decode(e.name, 'UNKNOWN',' ',e.name) sql_command,   
  s.SCHEMANAME, 
  s.PROGRAM||'/'||s.Module Current_Program,                                           
  s.CLIENT_INFO  
from 
  gv$session s, 
  gv$process p,   
  audit_actions e,  
  (select sid, trunc((1 - ( physical_reads /( block_gets  +consistent_gets)))*100) sess_hr   
   from gv$sess_io     
   where           
    (block_gets + consistent_gets) > 0        
   union                      
   select sid, 
     0 sess_hr      
   from gv$sess_io       
   where             
    (block_gets + consistent_gets ) = 0) io  
where s.paddr = p.addr   
and s.sid = io.sid     
and s.command = e.action      
