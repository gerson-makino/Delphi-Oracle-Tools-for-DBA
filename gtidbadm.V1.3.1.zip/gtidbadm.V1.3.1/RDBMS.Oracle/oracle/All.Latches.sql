SELECT latch#, name, gets, misses, sleeps
   FROM v$latch
  WHERE sleeps>0
  