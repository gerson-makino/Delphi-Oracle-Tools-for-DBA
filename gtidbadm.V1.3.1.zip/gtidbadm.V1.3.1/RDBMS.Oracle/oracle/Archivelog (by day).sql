select
  to_char(completion_time,  'dd/mm/yyyy')   xvalue,
  trunc(sum((blocks*block_size)/1024/1024)) yvalue0
 
from
  v$archived_log
where to_char(completion_time, 'yyyymm') = 
      to_char(sysdate, 'yyyymm') 
 
group by
  to_char(completion_time,  'dd/mm/yyyy')
 

