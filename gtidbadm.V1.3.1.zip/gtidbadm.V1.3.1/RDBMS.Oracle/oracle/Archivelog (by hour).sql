select
  to_char(completion_time,  'hh24')||':00' xvalue,
  trunc(sum((blocks*block_size)/1024/1024)) yvalue0
from
  v$archived_log
where 
  trunc(completion_time) = trunc(sysdate)
group by
  to_char(completion_time,  'hh24')||':00'
