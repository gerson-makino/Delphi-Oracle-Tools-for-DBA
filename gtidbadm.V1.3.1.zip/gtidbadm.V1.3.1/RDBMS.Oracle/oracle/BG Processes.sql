select 
  pserial#, name, description, error 
from 
  v$bgprocess 
