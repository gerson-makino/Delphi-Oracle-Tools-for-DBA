select 
  a.stat legend,
  trunc((sum(a.nbuf)/200000)*100) yvalue  
from (select status stat, count(*) nbuf 
      from v$bh group by status   
        union  
      select 'free', 0 from dual     
        union                          
      select 'xcur', 0 from dual      
        union                           
      select 'scur', 0 from dual      
        union                           
      select 'cr', 0 from dual        
        union                           
      select 'read', 0 from dual       
        union                            
      select 'mrec', 0 from dual      
        union                           
      select 'irec', 0 from dual) a   
 group by a.stat  
 order by a.stat   
