SELECT 
  name legend,    
 trunc((1-(physical_reads / (consistent_gets + db_block_gets ) ))*100 )  yvalue  
FROM 
V$BUFFER_POOL_STATISTICS  
WHERE 
( consistent_gets + db_block_gets ) !=0 
order by name 
