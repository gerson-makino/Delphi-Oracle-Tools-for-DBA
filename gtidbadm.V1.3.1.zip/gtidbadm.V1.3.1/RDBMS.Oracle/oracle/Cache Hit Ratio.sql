select  
  trunc( (1 - (pr.value - ( prd.value + prdl.value ) ) / 
  (dbg.value + cg.value - (prd.value + prdl.value )) ) * 100) yvalue
from      
  v$sysstat pr,
  v$sysstat prd,   
  v$sysstat prdl, 
  v$sysstat dbg,  
  v$sysstat cg    
where    
  pr.name = 'physical reads' and   
  prd.name = 'physical reads direct' and 
  prdl.name = 'physical reads direct (lob)' and 
  dbg.name = 'db block gets' and  
  cg.name = 'consistent gets' 
