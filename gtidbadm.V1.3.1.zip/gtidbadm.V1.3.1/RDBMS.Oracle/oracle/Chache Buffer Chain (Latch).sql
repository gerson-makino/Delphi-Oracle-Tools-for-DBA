SELECT  latch#, gets, misses, sleeps
    FROM v$latch_children
   WHERE sleeps>0
     and latch# = 66