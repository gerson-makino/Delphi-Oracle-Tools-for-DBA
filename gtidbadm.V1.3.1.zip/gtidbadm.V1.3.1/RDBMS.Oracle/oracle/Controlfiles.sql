select 
  * 
from 
  v$controlfile
