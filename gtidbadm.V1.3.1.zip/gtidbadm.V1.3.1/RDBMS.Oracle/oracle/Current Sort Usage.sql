select
  a.inst_id,
  a.sid,
  a.serial#,
  a.terminal,
  a.username,
  a.module,
  b.tablespace,
  b.contents,
  b.segtype,
  b.extents,
  b.blocks,
  c.sql_text
from
  gv$sort_usage b,
  gv$session a,
  gv$sqlarea c
where 
  b.session_num = a.serial#
  and b.sqladdr = c.address
