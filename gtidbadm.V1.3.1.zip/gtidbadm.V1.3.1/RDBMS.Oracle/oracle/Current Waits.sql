select count(*) Count, event from v$session_wait 
where state='WAITING' group by event  
