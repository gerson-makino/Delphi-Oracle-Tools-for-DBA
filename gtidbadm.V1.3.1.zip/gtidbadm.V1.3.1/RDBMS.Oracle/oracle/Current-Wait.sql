select 
  event, 
  sum(total_waits) total_waits, 
  sum(total_timeouts) total_timeouts, 
  sum(time_waited) time_waited, 
  sum(max_wait) max_wait
from 
  v$session_event 
group by 
  event