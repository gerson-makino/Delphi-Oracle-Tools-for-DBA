select 
  count(*) count, 
  name latchname 
from 
  v$session_wait, 
  v$latchname 
where 
  event='latch free' and 
  state='WAITING' and 
  p2=latch# 
group by 
  name 
