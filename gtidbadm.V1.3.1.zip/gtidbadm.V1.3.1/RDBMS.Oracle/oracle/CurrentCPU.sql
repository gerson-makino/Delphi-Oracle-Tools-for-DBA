select 
  'CPU Usage' title,
  50000 maxvalue,
  0 minvalue,
  'CPU(Ms)/Session' legend, 
  trunc(sum(value)/count(*)) yvalue 
from  
v$sesstat where statistic# = 12
