select   
  b.name, 
  sum( a.value) 
from 
  v$sesstat a, 
  v$statname b
where 
  a.statistic# = b.statistic#
group by 
  b.name