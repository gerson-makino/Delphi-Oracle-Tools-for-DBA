SELECT 
  a.inst_id,
  a.sid,
  a.serial#, 
  a.osuser,
  a.terminal,
  a.module,
  b.total_waits,
  b.total_timeouts,
  b.time_waited,
  trunc(b.average_wait,4) average_wait,
  b.max_wait
FROM 
  Gv$session_event b, 
  Gv$session a
WHERE 
  b.event='db file sequential read'
  and b.total_waits>0
  and a.sid = b.sid   