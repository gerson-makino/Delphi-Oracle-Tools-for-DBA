select
  'DB Time(ms)' legend,
  to_char(value/1000,'0000000000000000000.0000000') yvalue
from v$sys_time_model
where stat_name = 'DB CPU'