select 
  * 
from
  dba_db_links