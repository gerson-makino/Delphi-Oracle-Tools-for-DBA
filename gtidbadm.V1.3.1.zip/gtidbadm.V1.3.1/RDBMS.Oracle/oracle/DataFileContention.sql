select 
  count(*) "access", 
  f.name 
from  
  gv$session_wait w, 
  gv$datafile f 
where 
  w.p1text = 'file#'
  and w.p1 = f.file# 
group by 
  f.name