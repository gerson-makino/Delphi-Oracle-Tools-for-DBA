select 
  a.name  xvalue ,
 sum(b.phyrds+b.phywrts) yvalue0,
 sum(b.phyrds) yvalue1,
 sum(b.phywrts) yvalue2
from v$filestat b,
  v$datafile a
  where a.file# = b.file#
group by 
 a.name
order by 1
