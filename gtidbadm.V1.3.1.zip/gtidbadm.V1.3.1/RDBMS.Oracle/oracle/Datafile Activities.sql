select 
 substr(a.name,1,instr(a.name,'\',2,3)-1) xvalue ,
 sum(b.phyrds+b.phywrts) yvalue2,
 sum(b.phyrds) yvalue1,       
 sum(b.phywrts) yvalue0      
   
from v$filestat b,
  v$datafile a
  where a.file# = b.file#
group by 
 substr(a.name,1,instr(a.name,'\',2,3 )-1)
