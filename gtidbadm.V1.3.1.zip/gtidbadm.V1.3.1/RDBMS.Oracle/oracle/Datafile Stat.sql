select  
  a.name ,  
  c.name "ts", 
  b.phyrds,  
  b.phywrts,  
  b.phyrds+b.phywrts  
from 
  v$datafile a, 
  v$filestat b, 
  v$tablespace c  
where 
  a.file# = b.file# 
 and a.ts# = c.ts# 
union 
select  
  a.name  , 
  c.name "ts", 
  b.phyrds, 
  b.phywrts, 
  b.phyrds+b.phywrts  
from 
  v$tempfile a, 
  v$tempstat b, 
  v$tablespace c  
where 
  a.file# = b.file#  
  and a.ts# = c.ts#  