SELECT
   a.tablespace_name,
   a.file_name,
   trunc(a.bytes/1024/1024,2) size_MB,
   trunc(b.free_bytes/1024/1024,2) Free_MB, 
   trunc(100-((b.free_bytes/a.bytes)*100),3) used_perc
FROM
   dba_data_files a,
   (SELECT file_id, SUM(bytes) free_bytes
    FROM dba_free_space b GROUP BY file_id) b
WHERE
   a.file_id=b.file_id
ORDER BY
   a.tablespace_name
 