select 
 DEFERRED_TRAN_ID,       
 DELIVERY_ORDER,         
 DESTINATION_LIST,       
 to_date(START_TIME) start_time             
from 
  deftran 