select 
  parameter, 
  count,
  usage, 
  trunc(100*nvl(usage,0)/decode(count,null,1,0,1,count),1) pctused, 
  gets, 
  getmisses, 
  trunc(100*nvl(getmisses,0)/decode(gets,null,1,0,1,gets),1) pctmisses,
  decode( greatest(100*nvl(usage,0)/decode(count,null,1,0,1,count),80), 80, ' Lower', 
  decode(least(100*nvl(getmisses,0)/decode(gets,null,1,0,1,gets),10), 10, '*Raise', ' Ok') ) action 
from 
  v$rowcache 
 