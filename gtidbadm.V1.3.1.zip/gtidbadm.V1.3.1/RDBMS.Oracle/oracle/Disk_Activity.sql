select 
  a.leg  legend, 
  a.ct yvalue 
from 
(select 'Physical Read' leg , sum(phyrds) ct from v$filestat
   union all
select 'Physical Writes' leg , sum(phywrts) ct from v$filestat) a

