select
  s.inst_id,
  s.sid, 
  s.osuser, 
  s.username, 
  decode(s.TERMINAL, 'UNKNOWN ', '-oracle-', s.terminal) terminal,     
  s.program, 
  decode(w.EVENT, 'SQL*Net message from client','Term Wait', w.event) "event", 
  w.WAIT_TIME, 
  w.SECONDS_IN_WAIT, 
  f.name  
 from
  gv$session s,  gv$session_wait w, gv$datafile f 
where 
  s.sid = w.sid 
  and w.p1text = 'file#'
  and w.p1 = f.file# 

