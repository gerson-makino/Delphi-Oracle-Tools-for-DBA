select 
  * 
from 
  v$fixed_table
