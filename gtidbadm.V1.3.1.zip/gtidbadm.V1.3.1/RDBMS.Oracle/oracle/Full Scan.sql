select
  s.sid,
  s.osuser,
  s.username,
  decode(s.TERMINAL, 'UNKNOWN ', '-oracle-', s.terminal) terminal,
  s.program,
  w.WAIT_TIME,
  w.SECONDS_IN_WAIT,
  s.sql_text
 from
  v$session s,  
  v$session_wait w, 
  v$sqlarea s
where
  s.sid = w.sid
  and w.event = 'db file scattered read'
  and s.sql_address = s.address