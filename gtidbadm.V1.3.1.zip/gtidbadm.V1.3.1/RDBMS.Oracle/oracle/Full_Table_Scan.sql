select 
   p.owner, 
   p.name, 
   t.num_rows,
--   ltrim(t.cache) ch,
   decode(t.buffer_pool,'KEEP','Y','DEFAULT','N') KeepBuffer,
   s.blocks blocks,
   sum(a.executions) FullTableScan
from 
   dba_tables   t,
   dba_segments s,
   v$sqlarea    a,
   (select distinct 
     address,
     object_owner owner, 
     object_name name
   from 
      v$sql_plan
   where 
      operation = 'TABLE ACCESS'
      and
      options = 'FULL') p
where 
   a.address = p.address
   and
   t.owner = s.owner
   and
   t.table_name = s.segment_name
   and
   t.table_name = p.name
   and
   t.owner = p.owner
   and
   t.owner not in ('SYS','SYSTEM')
having
   sum(a.executions) > 1
group by 
   p.owner, p.name, t.num_rows, t.cache, t.buffer_pool, s.blocks
