select 
  * 
from 
  all_objects 
where 
  object_type = 'FUNCTION' 
  or object_type = 'PROCEDURE' 
  or object_type = 'PACKAGE' 
  or object_type = 'TRIGGER' 
  or object_type = 'PACKAGE BODY' 
  or object_type = 'TRIGGER' 
