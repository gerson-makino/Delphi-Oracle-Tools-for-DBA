select 
  s.inst_id,
  s.sid, 
  p.spid, 
  s.osuser, 
  s.username, 
  to_char(s.logon_time, 'dd/mm hh24:mi') logon_time,
  decode(s.TERMINAL, 'UNKNOWN ', '-oracle-', s.terminal) terminal,     
  s.program, 
  s.module,
  w.SEQ#, 
  decode(w.EVENT, 'SQL*Net message from client','Term Wait', w.event) "event", 
  w.P1TEXT, 
  w.P1, 
  w.P1RAW , 
  w.P2TEXT , 
  w.P2 , 
  w.P2RAW , 
  w.P3TEXT, 
  w.P3, 
  w.P3RAW   , 
  w.WAIT_TIME, 
  w.SECONDS_IN_WAIT, 
  decode(w.STATE, 'WAITING','Wait','WAITED UNKNOWN TIME','WaitUt',w.state) "state"  
from
  gv$session s,  
  gv$session_wait w, 
  gv$process p
where 
  s.sid = w.sid 
  and w.event <> 'SQL*Net message from client' 
  and w.event <> 'rdbms ipc message' 
  and s.paddr = p.addr 