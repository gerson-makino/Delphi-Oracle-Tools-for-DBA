select 
 a.name  ,
 sum(b.phyrds+b.phywrts) total_io,
 sum(PHYBLKRD),       
 sum(PHYBLKWRT),      
 sum(READTIM),        
 sum(WRITETIM),       
 sum(AVGIOTIM),       
 sum(LSTIOTIM),       
 sum(MINIOTIM),       
 sum(MAXIORTM),       
 sum(MAXIOWTM),
 '    ' title,
 avg(readtim) avread      
 from v$filestat b,
  v$datafile a
  where a.file# = b.file#
group by 
 a.name
