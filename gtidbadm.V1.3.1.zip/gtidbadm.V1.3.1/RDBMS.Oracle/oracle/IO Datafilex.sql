select 
 a.name,
 b.phyrds+b.phywrts total_io,
 PHYBLKRD,       
 pHYBLKWRT,      
 READTIM,        
 WRITETIM,       
 AVGIOTIM,       
 LSTIOTIM,       
 MINIOTIM,       
 MAXIORTM,       
 MAXIOWTM
 
 from 
v$filestat b,
  v$datafile a
  where a.file# = b.file#
