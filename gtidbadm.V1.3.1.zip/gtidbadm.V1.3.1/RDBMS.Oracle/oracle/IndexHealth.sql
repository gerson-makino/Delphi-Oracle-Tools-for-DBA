select 
  a.owner,
  a.index_name,
  b.blocks,
  b.pct_used,
  b.distinct_keys leaf_rows,
  b.del_lf_rows,
  (b.del_lf_rows/b.lf_rows) pctdel
from  
  dba_indexes a,
  index_stats b
where 
  a.owner not in ('SYS', 'SYSTEM')
  and a.index_name = b.name