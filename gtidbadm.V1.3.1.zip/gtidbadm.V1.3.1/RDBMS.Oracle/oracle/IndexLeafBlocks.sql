select 
  owner,
  index_name, 
  blevel, 
  leaf_blocks, 
  distinct_keys, 
  avg_leaf_blocks_per_key, 
  num_rows
from 
  dba_indexes 
where  
  num_rows > 0
  and avg_leaf_blocks_per_key > 1