select 
   p.owner, 
   d.table_name, 
   p.name index_name, 
   sum(s.executions) nbr_scans
from 
   v$sqlarea s,
   dba_indexes d,
  (select distinct 
     address, 
     object_owner owner, 
     object_name name
   from 
      v$sql_plan
   where 
      operation = 'INDEX'
      and
      options = 'UNIQUE SCAN') p
where 
   d.index_name = p.name
   and
   s.address = p.address
having
   sum(s.executions) > 9
group by 
   p.owner, d.table_name, p.name