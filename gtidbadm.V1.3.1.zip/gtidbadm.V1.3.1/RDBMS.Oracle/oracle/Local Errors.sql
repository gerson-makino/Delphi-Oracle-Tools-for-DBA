select 
  * 
from 
  dba_snapshot_logs
