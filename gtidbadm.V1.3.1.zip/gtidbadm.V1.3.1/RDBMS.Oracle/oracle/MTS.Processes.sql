select 
  d.network network, 
  d.name disp , 
  s.username oracle_user, 
  s.sid sid, 
  s.serial# serial# , 
  p.username os_user, 
  s.terminal terminal, 
  s.program program 
from 
  v$dispatcher d, 
  v$circuit c, 
  v$session s, 
  v$process p 
where 
  d.paddr = c.dispatcher (+) 
  and c.saddr = s.saddr (+) 
  and s.paddr = p.addr (+) 