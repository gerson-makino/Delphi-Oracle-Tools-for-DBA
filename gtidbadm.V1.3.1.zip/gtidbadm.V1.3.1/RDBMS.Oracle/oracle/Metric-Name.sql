select group_name, metric_name, metric_unit 
from v$metricname
order by group_name, metric_name
