select b.sql_id,  b.total, b.pctload, a.sql_text from
(SELECT sql_id,COUNT(*) total,ROUND(COUNT(*)/SUM(COUNT(*)) OVER(), 2) PCTLOAD
FROM gv$active_session_history
WHERE sample_time > SYSDATE - 2
AND session_type = 'FOREGROUND'
and sql_id is not null
GROUP BY sql_id) b,
 v$sqlarea a
where b.sql_id = a.sql_id
ORDER by b.total desc



