select 
  * 
from 
  v$nls_parameters 
