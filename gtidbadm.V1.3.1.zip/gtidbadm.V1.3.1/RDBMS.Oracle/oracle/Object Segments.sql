select 
  owner,
  segment_name, 
  segment_type, 
  tablespace_name, 
  extents,
  trunc(bytes/1024/1024) sizemb, 
  blocks, 
  initial_extent, 
  next_extent, 
  pct_increase 
from 
  dba_segments
where owner not in ('SYS', 'SYSTEM')
