select 
  owner,
  name,
  type,
  loads,
  executions 
from 
  sys.v_$db_object_cache 
where 
  owner not like 'SYS%' 
  and owner not like 'PUBLIC' 
