select 
  'TABLE' object_type,
  owner,
  table_name objname,
  last_analyzed
from dba_tables
where 
  owner not in ('SYS', 'SYSTEM')
and
  last_analyzed is not null
union all 
select 
  'INDEX' objtype,
  owner,
  index_name objname,
  last_analyzed
from dba_indexes
where 
  owner not in ('SYS', 'SYSTEM')
and
  last_analyzed is not null
 
