select 
  'TABLE' object_type,
  owner, 
  table_name,
  logging
from 
  dba_tables
where 
  logging <> 'YES' and
  owner not in ('SYS', 'SYSTEM')
union all
select 
  'INDEX' object_type,
  owner, 
  index_name,
  logging
from 
  dba_indexes
where 
  logging <> 'YES' and
  owner not in ('SYS', 'SYSTEM')
