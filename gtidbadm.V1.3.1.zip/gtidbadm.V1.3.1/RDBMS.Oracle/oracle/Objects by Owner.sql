select 
  owner, 
  object_type, 
  count(*) ct 
from 
  dba_objects
group by 
  owner, object_type

