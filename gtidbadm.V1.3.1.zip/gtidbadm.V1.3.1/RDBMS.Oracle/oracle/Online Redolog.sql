select 
  a.group#,
  a.status,
  a.member,
  b.thread#, 
  b.sequence#,
  trunc(b.bytes/1024/1024) size_mb,
  b.archived, 
  b.first_change#,
  to_char(b.first_time, 'DD/MM/YYYY HH24:MI') first_time 
from 
  v$logfile a, 
  v$log b 
where 
  a.group# = b.group# 
