select 
  a.inst_id,
  a.sid,
  b.serial#, 
  b.username,
  b.terminal,
  b.program,
  a.sql_text 
from 
  gv$open_cursor  a, 
  gv$session b
where 
  a.sid = b.sid
