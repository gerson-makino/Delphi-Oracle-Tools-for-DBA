select 
  * 
from 
  v$pwfile_users
