select 
  * 
from 
  v$parameter
 
