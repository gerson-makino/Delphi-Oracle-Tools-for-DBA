select 
  * 
from 
  dba_profiles
