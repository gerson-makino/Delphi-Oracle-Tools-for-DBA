select 
  * 
from 
  all_refresh
