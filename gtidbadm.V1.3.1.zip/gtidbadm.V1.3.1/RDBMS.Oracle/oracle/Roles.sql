select 
  * 
from 
  dba_roles
