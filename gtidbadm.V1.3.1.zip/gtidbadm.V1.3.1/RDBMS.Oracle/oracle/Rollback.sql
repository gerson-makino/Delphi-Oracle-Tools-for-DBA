SELECT 
  n.NAME, 
  rbs.tablespace_name,
  rbs.INITIAL_EXTENT, 
  rbs.NEXT_EXTENT,    
  rbs.MIN_EXTENTS,    
  rbs.MAX_EXTENTS,    
  rbs.PCT_INCREASE,   
  DECODE(rs.status,'ONLINE','ON','OFF') status, 
  rs.EXTENTS,   
  rs.OPTSIZE, 
  rs.SHRINKS, 
  rs.AVESHRINK, 
  trunc(rs.AVEACTIVE/1024,2) aveactive , 
  rs.XACTS, 
  trunc(rs.HWMSIZE/1024,2) hwmsize, 
  trunc(rs.RSSIZE/1024,2) rssize, 
  rs.WAITS,  
  rs.WRAPS, 
  rs.EXTENDS  
FROM 
  V$ROLLNAME n, 
  V$ROLLSTAT rs,  
  dba_rollback_segs rbs
WHERE   
   rs.usn(+) = n.usn  
   and n.name = rbs.segment_name
