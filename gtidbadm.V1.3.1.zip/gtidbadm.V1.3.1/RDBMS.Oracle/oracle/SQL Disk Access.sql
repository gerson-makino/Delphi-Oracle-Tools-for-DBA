select 
  SQL_TEXT,
  EXECUTIONS,
  LOADS,
  DISK_READS,
  PERSISTENT_MEM,
  RUNTIME_MEM  
from 
  sys.V_$sqlarea 
where 
  disk_reads > 0 
  and sql_text not like '%$%' 
  and sql_text not like '%DBA_%' 
