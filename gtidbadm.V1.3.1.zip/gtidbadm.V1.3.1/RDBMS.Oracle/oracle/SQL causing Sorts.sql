select 
  executions,
  sorts,
  sql_text
from 
  v$sqlarea
where 
  sorts > 50
