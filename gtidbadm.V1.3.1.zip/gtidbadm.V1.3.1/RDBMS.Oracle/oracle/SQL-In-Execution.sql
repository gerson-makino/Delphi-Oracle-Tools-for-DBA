select 
  sorts, 
  executions, 
  users_executing, 
  disk_reads, 
  sql_text
from 
  v$sqlarea 
where 
  users_executing > 0