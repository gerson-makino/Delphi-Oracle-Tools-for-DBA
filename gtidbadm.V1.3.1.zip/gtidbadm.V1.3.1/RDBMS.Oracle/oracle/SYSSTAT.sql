select
  'CPU TIME' title,
  2000 maxvalue,
  0 minvalue,
  stat_name legend,
  value yvalue
from
v$osstat
where stat_name in ('IDLE_TIME', 'BUSY_TIME', 'USER_TIME', 'SYS_TIME')