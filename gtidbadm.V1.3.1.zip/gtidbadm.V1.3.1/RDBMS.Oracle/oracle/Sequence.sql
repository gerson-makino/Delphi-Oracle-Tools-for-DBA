select 
  * 
from 
  all_objects 
where 
  object_type = 'SEQUENCE'
