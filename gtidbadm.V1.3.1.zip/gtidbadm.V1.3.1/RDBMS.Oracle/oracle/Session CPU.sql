select
  c.inst_id,  
  a.sid,    
  c.serial#,   
  d.state,   
  c.username, 
  c.osuser, 
  c.terminal,
  to_char(c.LOGON_TIME,'dd/mon hh24:mi') logon_time,  
  a.value,  
  b.total,   
  decode(c.LOCKWAIT,null,' ','Yes')  lockwait ,  
  trunc((value/b.total)*100,3) cpu_perc,     
  decode(e.name, 'UNKNOWN', ' ', e.name) command  
from 
  gv$sesstat a,    
  (select sum(value) total from gv$sesstat where statistic#= 12) b,  
  gv$session c,  
  gv$session_wait d,   
  audit_actions e   
where 
  statistic# = 12  
  and value > 0      
  and a.sid = c.sid   
  and d.sid = a.sid  
  and c.command = e.action
 