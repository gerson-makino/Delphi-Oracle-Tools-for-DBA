select
  'Active Session History' title,
  to_char(to_date(tday||' '||tmod*3600,'YYMMDD SSSSS'),'DD-MON  HH24:MI:SS') xvalue,
  to_char(cpu/3600,'00.00000') yvalue0,
  'cpu' legend0,
  to_char(waits/3600,'00.00000') yvalue1,
  'WAITS' legend1,
  '?' yvalue2,
  '?' legend2,
  p.value*2 maxvalue
from (
   select
       to_char(sample_time,'YYMMDD')  tday
     , sum(decode(session_state,'ON CPU',1,decode(session_type,'BACKGROUND',0,1)))  total
     , trunc(to_char(sample_time,'SSSSS')/3600) tmod
     , sum(decode(session_state,'ON CPU' ,1,0)) cpu
     , sum(decode(session_type,'BACKGROUND',0,decode(session_state,'WAITING',1,0)))  waits
       /* for waits I want to subtract out the BACKGROUND
          but for CPU I want to count everyon */
   from
      v$active_session_history
   where sample_time > sysdate - 8
   group by  trunc(to_char(sample_time,'SSSSS')/3600),
             to_char(sample_time,'YYMMDD')
union all
   select
       to_char(sample_time,'YYMMDD') tday
     , sum(decode(session_state,'ON CPU',10,decode(session_type,'BACKGROUND',0,10))) total
     , trunc(to_char(sample_time,'SSSSS')/3600) tmod
     , sum(decode(session_state,'ON CPU' ,10,0)) cpu
     , sum(decode(session_type,'BACKGROUND',0,decode(session_state,'WAITING',10,0))) waits
       /* for waits I want to subtract out the BACKGROUND
          but for CPU I want to count everyon */
   from
      dba_hist_active_sess_history
   where sample_time > sysdate - 8
   and sample_time < (select min(sample_time) from v$active_session_history)
   group by  trunc(to_char(sample_time,'SSSSS')/3600),
             to_char(sample_time,'YYMMDD')
) ash,
  v$parameter p
where 
  p.name='cpu_count'
order by 
  to_date(tday||' '||tmod*3600,'YYMMDD SSSSS')