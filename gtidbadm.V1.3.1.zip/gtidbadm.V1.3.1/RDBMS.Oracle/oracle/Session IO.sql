select 
  a.inst_id,
  a.sid, 
  b.serial#, 
  b.username, 
  b.terminal, 
  b.osuser,
  a.block_gets,
  a.consistent_gets,
  a.physical_reads,
  a.block_changes,
  a.consistent_changes
from 
  gv$sess_io a,
  gv$session b
where 
  a.sid = b.sid 
  and (a.block_gets > 0 or a.consistent_gets > 0 or a.physical_reads > 0 or 
       a.block_changes > 0 or a.consistent_changes > 0)