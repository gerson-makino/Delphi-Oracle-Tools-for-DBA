select sid,
serial#,
username,
osuser,
terminal,
status, 
to_char(logon_time,'dd-mm-yy hh:mi:ss') "LOGON", 
floor(last_call_et/3600)||':'|| floor(mod(last_call_et,3600)/60)||':'|| mod(mod(last_call_et,3600),60) "IDLE",
 program 
from
 v$session 
where
 type='USER' 
 

