Select 
  a.inst_id, 
  a.sid, 
  a.serial#, 
  b.username,
  b.terminal,
  to_char(a.start_time, 'DD/MM HH24:MI')  "start_time",  
  a.time_remaining,  
  a.elapsed_seconds,   
  substr(a.message,1,200) message  
from 
  gv$session_longops a,
  gv$session b   
where 
  a.time_remaining > 0 
  and a.sid = b.sid  
