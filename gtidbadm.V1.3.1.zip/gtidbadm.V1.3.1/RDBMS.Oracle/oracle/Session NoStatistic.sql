select 
  e.inst_id, 
  e.sid, 
  e.serial#,   
  e.terminal,   
  a.os_user_name,  
   d.start_time ,      
  a.oracle_username,  
  b.object_name,    
  b.object_type,  
  c.segment_name, 
  d.used_urec,   
  d.used_ublk,  
  d.log_io,   
  d.phy_io,  
  d.cr_get,  
  d.cr_change   
from   
  gv$locked_object a,  
  dba_objects b,    
  dba_rollback_segs  c,  
  gv$transaction d,   
  gv$session e   
where    
  a.object_id   = b.object_id   
  and a.xidusn  = c.segment_id   
  and a.xidusn  = d.xidusn    
  and a.xidslot = d.xidslot  
  and d.addr = e.taddr
  and exists 
(select 1 from dba_tables where table_name = b.object_name and (last_analyzed is 
null
 or last_analyzed < sysdate-5))
