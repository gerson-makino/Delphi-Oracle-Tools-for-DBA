select 
  e.inst_id, 
  e.sid, 
  e.serial#,   
  e.terminal, 
  w.event,   
  a.os_user_name,  
   d.start_time ,      
  a.oracle_username,  
  b.object_name,    
  b.object_type,  
  c.segment_name, 
  d.used_urec,   
  d.used_ublk,  
  d.log_io,   
  d.phy_io,  
  d.cr_get,  
  d.cr_change   
from   
  v$locked_object a,  
  dba_objects b,    
  dba_rollback_segs  c,  
  v$transaction d,   
  gv$session e, 
  v$session_wait w  
where    
  a.object_id   = b.object_id   
  and a.xidusn  = c.segment_id   
  and a.xidusn  = d.xidusn    
  and a.xidslot = d.xidslot  
  and d.addr = e.taddr
  and e.sid = w.sid
  and (w.event = 'SQL*Net message from client' 
  or w.event = 'rdbms ipc message') 
  
