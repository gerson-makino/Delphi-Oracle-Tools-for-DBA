select
  a.inst_id,
  a.sid, 
  a.serial#,
  a.terminal,
  a.username,
  a.osuser, 
  b.sorts, 
  b.executions, 
  b.users_executing, 
  b.disk_reads, 
  b.sql_text
from 
  gv$session a,
  v$sqlarea b 
where 
  b.users_executing > 0
  and a.sql_address = b.address
