select 
  s.inst_id,
  s.sid,
  s.serial#,
  p.spid, 
  s.username, 
  to_char(s.logon_time, 'dd/mm hh24:mi') logon_time,
  decode(s.TERMINAL, 'UNKNOWN ', '-oracle-', s.terminal) terminal,     
  s.program, 
  decode(w.EVENT, 'SQL*Net message from client','Term Wait', w.event) "event", 
  w.SECONDS_IN_WAIT Wait_Sec, 
  decode(s.LOCKWAIT,null,' ','(w) Yes') "IS Locked?", 
  decode(w.event,'db file scattered read', '(w) Yes', ' ') "Is Fullscan?", 
  decode(w.STATE, 'WAITING','Wait','WAITED UNKNOWN TIME','WaitUt',w.state) "state",  
  w.P1TEXT||'= '||w.p1 p1_Event,
  w.P2TEXT||'= '||w.p2 p2_Event,
  w.P3TEXT||'= '||w.p3 p3_Event,
  sql.sql_text
from
  gv$session s,  
  gv$session_wait w, 
  gv$process p, 
  gv$sqlarea sql
where 
  s.sid = w.sid 
  and w.event <> 'SQL*Net message from client' 
  and w.event <> 'rdbms ipc message' 
  and s.paddr = p.addr 
  and s.sql_address = sql.address (+)