select 
  s.inst_id,
  s.sid,
  s.serial#,
  p.spid, 
  s.username 
from
  gv$session s,  
  gv$session_wait w, 
  gv$process p, 
  gv$sqlarea sql
where 
  s.sid = w.sid 
  and w.event <> 'SQL*Net message from client' 
  and w.event <> 'rdbms ipc message' 
  and s.paddr = p.addr 
  and s.sql_address = sql.address (+)