select 
  'sessoes ativas' title,
  500 maxvalue,
  0 minvalue,
  'sessoes' legend, 
  count(*) yvalue 
from  
v$session where status = 'ACTIVE'