select 
  'Shared Pool Used' legend, 
  round(((a.sizem-b.freem)/a.sizem)*100 ) yvalue 
from    
  (select
    trunc(sum(bytes)/1024/1024) sizem 
   from 
   v$sgastat 
   where pool= 'shared pool') a,  
  (select  
    trunc( bytes/1024/1024) freem 
   from 
   v$sgastat 
   where 
   pool= 'shared pool' 
   and name = 'free memory') b  
