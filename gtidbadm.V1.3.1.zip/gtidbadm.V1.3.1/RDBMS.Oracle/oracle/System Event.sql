select 
  * 
from 
  v$system_event
