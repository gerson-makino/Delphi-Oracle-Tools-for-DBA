select 
  * 
from 
  v$sysstat
