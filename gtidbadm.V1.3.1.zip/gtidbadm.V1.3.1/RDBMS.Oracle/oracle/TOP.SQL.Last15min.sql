SELECT a.user_id,d.username,
SUM(a.wait_time + a.time_waited) total_wait_time,
s.sql_text
FROM v$active_session_history a,
v$sqlarea s,
dba_users d
WHERE a.sample_time between sysdate - 30/2880 and sysdate
AND a.sql_id = s.sql_id
AND a.user_id = d.user_id
GROUP BY a.user_id,s.sql_text, d.username
order by 3 desc