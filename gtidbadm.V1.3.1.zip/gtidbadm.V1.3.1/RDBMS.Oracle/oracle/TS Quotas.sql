select 
  * 
from 
  DBA_TS_QUOTAS
 
