select  
  tablespace_name, 
  sum(extents), 
  sum(blocks) 
from 
  dba_segments  
group by 
  tablespace_name 
