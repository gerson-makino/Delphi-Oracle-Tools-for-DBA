select 
  s.sid, 
  s.osuser, 
  s.username, 
  decode(s.TERMINAL, 'UNKNOWN ', '-oracle-', s.terminal) terminal,     
  s.program, 
  s.module,
  w.SEQ#, 
  w.WAIT_TIME, 
  w.SECONDS_IN_WAIT,
  f.owner, 
  f.segment_type,  
  f.segment_name 
 from
  v$session s,  v$session_wait w, dba_extents f 
where 
  s.sid = w.sid 
  and w.p1text = 'file#'
  and w.p1 = f.file_id 
  and w.p2 between f.block_id and    f.block_id+f.blocks-1

