select 
   p.owner, 
   p.name, 
   t.num_rows,
   sum(s.executions) nbr_RID
from 
   dba_tables t,
   v$sqlarea s,
  (select distinct 
     address, 
     object_owner owner, 
     object_name name
   from 
      v$sql_plan
   where 
      operation = 'TABLE ACCESS'
      and
      options = 'BY ROWID') p
where 
   s.address = p.address
   and
   t.table_name = p.name
   and
   t.owner = p.owner
having
   sum(s.executions) > 1
group by 
   p.owner, p.name, t.num_rows