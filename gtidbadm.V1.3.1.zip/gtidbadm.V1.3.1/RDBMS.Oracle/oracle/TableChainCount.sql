select 
  owner, 
  table_name,
  blocks,
  num_rows, 
  chain_cnt 
from 
  dba_tables 
where 
  chain_cnt > 0
