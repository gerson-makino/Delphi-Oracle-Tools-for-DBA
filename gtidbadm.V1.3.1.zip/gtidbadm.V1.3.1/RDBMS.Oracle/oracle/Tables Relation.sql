select 
  a1.TABLE_NAME,
  c1.column_name,
  a2.TABLE_NAME "TABLE_NAME2",
  c2.column_name "column_name2" 
from 
  all_constraints a1,
  all_constraints a2,
  ALL_CONS_COLUMNS c1,
  ALL_CONS_COLUMNS c2 
where 
  a1.CONSTRAINT_NAME=a2.R_CONSTRAINT_NAME 
  and a1.TABLE_NAME != a2.TABLE_NAME 
  and c1.CONSTRAINT_NAME=a1.CONSTRAINT_NAME 
  and c2.CONSTRAINT_NAME=a2.Constraint_NAME
