select 
  tsname  xvalue ,
 totalio yvalue0,
 totalread yvalue1,
 totalwrite yvalue2      
   
 from (select
  c.name tsname,
  sum(b.phyrds) totalread,
  sum(b.phywrts)totalwrite,
  sum(b.phyrds+b.phywrts) totalio
from
  v$datafile a,
  v$filestat b,
  v$tablespace c
where
  a.file# = b.file#
 and a.ts# = c.ts#
group by c.name
union
select
  c.name tsname,
  sum(b.phyrds) totalread,
  sum(b.phywrts)totalwrite,
  sum(b.phyrds+b.phywrts) totalio
from
  v$tempfile a,
  v$tempstat b,
  v$tablespace c
where
  a.file# = b.file#
  and a.ts# = c.ts#
group by c.name)


