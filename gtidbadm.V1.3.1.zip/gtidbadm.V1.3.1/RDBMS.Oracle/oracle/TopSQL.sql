select 
disk_reads,
buffer_gets,
executions,
sql_text
from
v$sqlarea
where
disk_reads > 500
and buffer_gets > 500
