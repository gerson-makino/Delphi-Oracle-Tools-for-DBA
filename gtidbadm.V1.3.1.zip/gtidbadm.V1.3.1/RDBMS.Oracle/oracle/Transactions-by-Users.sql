select
  e.inst_id,
  e.sid,
  e.serial#,
  e.terminal,
  a.os_user_name,
  a.oracle_username,
  sum(d.used_urec) urec,
  sum(d.used_ublk) ublk,
  sum(d.log_io) log_io,
  sum(d.phy_io) phy_io,
  sum(d.cr_get) cr_get,
  sum(d.cr_change) cr_change
from
  gv$locked_object a,
  dba_objects b,
  dba_rollback_segs  c,
  gv$transaction d,
  gv$session e
where
  a.object_id   = b.object_id
  and a.xidusn  = c.segment_id
  and a.xidusn  = d.xidusn
  and a.xidslot = d.xidslot
  and d.addr = e.taddr
group by
 e.inst_id, e.sid, e.serial#, e.terminal, a.os_user_name, a.oracle_username