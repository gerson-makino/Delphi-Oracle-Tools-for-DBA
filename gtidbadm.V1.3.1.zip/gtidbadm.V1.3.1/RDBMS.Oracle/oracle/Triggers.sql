select 
 OWNER,                  
 TRIGGER_NAME ,          
 TRIGGER_TYPE,           
 TRIGGERING_EVENT,       
 TABLE_OWNER,            
 BASE_OBJECT_TYPE,       
 TABLE_NAME,             
 COLUMN_NAME,            
 REFERENCING_NAMES,      
 WHEN_CLAUSE,           
 STATUS,                 
 DESCRIPTION   
from
  dba_triggers         
 ACTION_TYPE   
