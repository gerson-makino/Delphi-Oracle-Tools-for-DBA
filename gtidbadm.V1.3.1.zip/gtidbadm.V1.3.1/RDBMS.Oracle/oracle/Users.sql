select 
  * 
from 
  dba_users
