select 
  * 
from 
  v$version
