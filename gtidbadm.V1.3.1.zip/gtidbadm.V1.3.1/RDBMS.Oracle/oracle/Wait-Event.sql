select 
  waitclass xvalue,  
  to_char( ((timew/totalt)*100),'00.000') yvalue
from
(select b.wait_class waitclass, sum(a.time_waited) timew
from v$system_event a,
v$event_name b
where b.name = a.event
group by b.wait_class) a,
(select sum(time_waited) totalt from v$system_event) b