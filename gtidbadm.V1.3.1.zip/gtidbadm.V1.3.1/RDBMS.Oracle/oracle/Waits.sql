select 
  class,
  count,
  time 
from 
v$waitstat  