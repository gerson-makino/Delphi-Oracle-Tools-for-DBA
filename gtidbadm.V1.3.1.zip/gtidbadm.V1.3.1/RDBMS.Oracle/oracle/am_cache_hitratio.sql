select 
  db_id,
  trunc(value) value,
  count(*) qtde
from
  dcp_perfstat
where
  stat_id = 'BUFFER_CACHE'
group by db_id, trunc(value)
