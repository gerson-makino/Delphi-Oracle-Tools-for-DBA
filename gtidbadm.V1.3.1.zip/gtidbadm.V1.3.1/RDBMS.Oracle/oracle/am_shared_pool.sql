select 
  db_id,
  value,
  count(*) qtde
from
  dcp_perfstat
where
  stat_id = 'SHARED_POOL'
group by db_id, value