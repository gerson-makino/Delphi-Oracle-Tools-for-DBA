select
  'dcp - buffer cache hitratio' title,
  100 maxvalue,
  0 minvalue,
  'hitratio' legend,
  to_char(timestamp,'hh') xvalue,
  trunc(avg(value)) yvalue
from
  dcp_perfstat
where
  stat_id = 'BUFFER_CACHE'
  and
  trunc(timestamp) = trunc(sysdate) 
group by 
  to_char(timestamp,'hh')
order by 1
