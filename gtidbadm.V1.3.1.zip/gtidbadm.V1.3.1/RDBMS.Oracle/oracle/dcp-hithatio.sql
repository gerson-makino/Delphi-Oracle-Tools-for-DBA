select
  'dcp - buffer cache hitratio' title,
  100 maxvalue,
  0 minvalue,
  'hitratio' legend,
  to_char(timestamp,'DD') xvalue,
  trunc(avg(value)) yvalue
from
  dcp_perfstat
where
  stat_id = 'BUFFER_CACHE'
  and
  timestamp 
  between 
    to_date(to_char(sysdate,'yyyymm')||'01','YYYYMMDD') 
    and add_months(sysdate,1)
group by
  to_char(timestamp,'DD')
order by 1
