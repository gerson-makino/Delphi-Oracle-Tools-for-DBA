select 
* from dcp_perfstat
