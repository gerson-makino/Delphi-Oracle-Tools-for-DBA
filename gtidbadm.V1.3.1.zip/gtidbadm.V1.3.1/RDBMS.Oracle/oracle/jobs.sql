select job, log_user, schema_user, last_date, this_date, next_date, total_time, broken, interval, failures, what
from dba_jobs