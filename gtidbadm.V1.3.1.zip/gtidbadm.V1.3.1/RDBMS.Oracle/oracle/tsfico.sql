select a.tsname, 
  to_number(trunc(((a.sizemb-b.freemb)/a.sizemb)*100)) perc from
 (select tablespace_name tsname, sum(bytes/1024/1024) sizemb from dba_data_files
 group by tablespace_name)  a,
 (select tablespace_name tsname, trunc(sum(bytes/1024/1024)) freemb
from dba_free_space
 group by tablespace_name
 union
  select tablespace_name tsname,  0 freemb from dba_tablespaces x
  where not exists (select 1 from dba_free_space where tablespace_name = x.tablespace_name)) b
where a.tsname = b.tsname  
  and a.tsname like 'T1_OPS_RUNTIME_OS_USR'
