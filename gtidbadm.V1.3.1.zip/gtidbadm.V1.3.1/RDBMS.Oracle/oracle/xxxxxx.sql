select 
  'Current CPU' title,
  500 maxvalue,
  0 minvalue,
  'CPU Time (ms) ' legend, 
  sum(value) yvalue 
from  
  v$sesstat where statistic#= 12 
