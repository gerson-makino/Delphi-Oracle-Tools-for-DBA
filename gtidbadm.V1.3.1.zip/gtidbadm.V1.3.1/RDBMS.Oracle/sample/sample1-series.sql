select 
  state,
  count(*) ctwait
from
  v$session
group by
  state
