select
  stat_name legend,
  value yvalue
from
v$osstat
where stat_name in ('IDLE_TIME', 'BUSY_TIME', 'USER_TIME', 'SYS_TIME')