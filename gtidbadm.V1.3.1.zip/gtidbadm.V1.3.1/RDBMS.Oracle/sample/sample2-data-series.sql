select 
  '2000' maxvalue,
  '0' minvalue,
  'Active Sessions' legend,
  'Average Active Sessions (last 2 days)' title,
  to_char(end_interval_time,'dd/mm/yyyy hh24')||':00' xvalue,
  trunc(avg(v_ps),3) yvalue
from (
select end_interval_time
, instance_number
, v/ela v_ps
from (
select round(s.end_interval_time,'hh24') end_interval_time
, s.instance_number
, (case when s.begin_interval_time = s.startup_time
then value
else value - lag(value,1) over (partition by sy.stat_id
, sy.dbid
, s.instance_number
, s.startup_time
order by sy.snap_id)
end)/1000000 v
, (cast(s.end_interval_time as date) - cast(s.begin_interval_time as date))*24*3600 ela
from dba_hist_snapshot s
, dba_hist_sys_time_model sy
where s.dbid = sy.dbid
and s.instance_number = sy.instance_number
and s.snap_id = sy.snap_id
and sy.stat_name = 'DB time'
and s.end_interval_time > to_date(sysdate-7)
and s.end_interval_time < to_date(sysdate+1) ))
group by to_char(end_interval_time,'dd/mm/yyyy hh24')||':00', instance_number
order by to_char(end_interval_time,'dd/mm/yyyy hh24')||':00', instance_number