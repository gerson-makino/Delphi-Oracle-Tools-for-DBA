select 
  to_char(Completion_time,'dd/mm/yyyy hh24')||':00' xvalue,
  count(*) yvalue
from 
  v$archived_log
where
  completion_time > sysdate - 7
group by
  to_char(Completion_time,'dd/mm/yyyy hh24')||':00'
