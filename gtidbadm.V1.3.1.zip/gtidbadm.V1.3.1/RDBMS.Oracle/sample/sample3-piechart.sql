select 
  object_type ylegend,
  count(*) yvalue
from
  all_objects
group by
  object_type