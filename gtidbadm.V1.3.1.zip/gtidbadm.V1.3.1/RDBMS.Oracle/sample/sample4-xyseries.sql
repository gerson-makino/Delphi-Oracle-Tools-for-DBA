select
  to_char(completion_time,'dd') xvalue,   
  count(*) yvalue    
from 
  v$archived_log
where 
  to_char(completion_time, 'mm/yyyy') = to_char(sysdate-2,'mm/yyyy')
group by 
to_char(completion_time,'yymmdd'),
  to_char(completion_time, 'dd')
order by xvalue
