select 
  b.tablespace_name  xvalue,
  trunc(((kbytes_alloc-kbytes_free)/kbytes_alloc)*100,1) yvalue0,
  trunc(((kbytes_alloc-kbytes_free)/kbytes_alloc)*100,1) yvalue1,
  trunc(((kbytes_alloc-kbytes_free)/kbytes_alloc)*100,1) yvalue2
from 
  ( select 
      trunc(sum(bytes)/1024/1024) Kbytes_free, 
      trunc(max(bytes)/1024/1024) largest, 
      tablespace_name  
    from 
      sys.dba_free_space 
    group by 
      tablespace_name  
    union    
    select  
      trunc((sum(free_blocks)*8192)/1024/1024) kbytes_free , 
      0 largest,  
      tablespace_name 
    from 
      v$sort_segment  
    group by 
      tablespace_name) a, 
  ( select 
      trunc(sum(bytes)/1024/1024) Kbytes_alloc, 
      tablespace_name  
    from 
      sys.dba_data_files  
    group by 
      tablespace_name 
    union    
    select 
      trunc(sum(bytes)/1024/1024) kbytes_alloc, 
      tablespace_name 
    from 
      dba_temp_files 
    group by 
      tablespace_name) b, 
  dba_tablespaces c   
where 
  a.tablespace_name (+) = b.tablespace_name
  and  a.tablespace_name = c.tablespace_name 
