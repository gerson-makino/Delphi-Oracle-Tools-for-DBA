select
  'Sample BAR' title,
  to_char(completion_time,  'dd/mm/yyyy')   xvalue,
  trunc(sum((blocks*block_size)/1024/1024)) yvalue0,
  'legend 0' legend0,
  trunc(sum((blocks*block_size)/1024/1024)) yvalue1,
  'legend 1' legend1,
  '?' yvalue2,
   200 maxvalue
from
  v$archived_log
where to_char(completion_time, 'yyyymm') = 
      to_char(sysdate, 'yyyymm') 
 
group by
  to_char(completion_time,  'dd/mm/yyyy')