 select 
   sid, 
   serial#, 
   terminal, 
   username 
 from 
   v$session
order by sid desc

