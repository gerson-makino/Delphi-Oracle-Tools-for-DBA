select 
  username, 
  sid 
from 
  v$session