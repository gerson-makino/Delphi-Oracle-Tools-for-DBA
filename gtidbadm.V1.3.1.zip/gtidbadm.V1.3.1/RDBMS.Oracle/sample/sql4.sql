select
  sid,
  p1text, 
  p1,
  p2text,
  p2
from 
  v$session_wait
