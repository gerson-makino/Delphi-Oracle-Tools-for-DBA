select sid, serial#, terminal, machine, osuser from v$session
where machine = upper('&machine') and
  terminal = upper('&terminal')
